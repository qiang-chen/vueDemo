<template>
  <div>
    <header>
      <div class="title">影院</div>
    </header>
    <div class="list">
      
    </div>
  </div>
</template>



<style lang="scss" scoped>
header {
  width: 100%;
   .title {
    height: 1rem;
    background-color: red;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 0.46rem;
  }}
.list {
  width: 100%;
  height: 100%;
}
</style>