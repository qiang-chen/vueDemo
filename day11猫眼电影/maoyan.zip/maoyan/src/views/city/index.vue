<template>
  <div class="cityContainer">
      {{cityList}}
    <div class="cityList">
      <div class="cityItem" v-for="(item,index) in cityList" :key="item.id">
        <h3>{{index}}</h3>
        <p v-for="(el,ind) in item" :key="ind">{{el.nm}}</p>
      </div>
    </div>
  </div>
</template>


<script>
//引入api下面js封装获取请求城市的函数
import { getCityList } from "@/api/index";
console.log(getCityList, "获取城市列表数据的函数封装");
export default {
  data() {
    return {
      cityList: {}
    };
  },

  //在城市列表请求城市数据
  async created() {
      console.log(11111111111111111111111111111111111)
    let data = await getCityList();
    data = data.cts;
    //首先将数据按照字母的顺序排序一波
    data.sort((a, b) => a.py.slice(0, 1).localeCompare(b.py.slice(0, 1)));
    //此时数组已经排序之后的了 接着截取里面每个字母组成一个新的数组
    let letterArr = Array.from(
      new Set(data.map(item => item.py[0].toLocaleUpperCase()))
    );
    //此时到了这里letterArr已经是我们处理好的一个存放26个字母排序后的存放的数组了
    //接着去data声明一个对象格式为{A：[{},{}]} A后面跟着所有的属于A的对象
    console.log(letterArr);
    //遍历循坏data这个对象判断ABCD为首的key是不是存在 存在的话就往后push 不存在就创建一个
    data.forEach(item => {
      let initial = item.py.slice(0, 1).toLocaleUpperCase();
      if (this.cityList[initial]) {
        this.cityList[initial].push(item);
      } else {
        this.cityList[initial] = [item];
      }
    });
    console.log(this.cityList, "城市列表数据");
    console.log(this.$route);
  }
};
</script>

<style lang="scss" scoped>
.cityContainer{
    width: 100%;
    height: 100%;
}
.cityList {
  width: 100%;
  background: #ebebeb;
}
</style>